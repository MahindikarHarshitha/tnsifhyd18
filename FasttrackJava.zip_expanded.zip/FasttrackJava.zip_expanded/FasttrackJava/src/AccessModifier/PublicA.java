package AccessModifier;

public class PublicA {
 public void display()
 {
	 System.out.println("hello");
 }
}

