package AccessModifier;

public class DefaultA {
void display()
{
	System.out.println("hello world");
}
}
