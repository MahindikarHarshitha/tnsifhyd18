package AccessModifier;

public class PublicMain {
public static void main(String[] args) {
	PublicA obj = new PublicA();
	obj.display();
}
}
