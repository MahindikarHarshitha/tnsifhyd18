package AccessModifier;

public class PrivateMain {
	public static void main(String[] args) {
		Private1 obj=new Private1();
		obj.display();
	}

}
