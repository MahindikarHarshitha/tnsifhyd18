package AccessModifier;

public class ProtectedA {
 protected void display()
 {
	 System.out.println("hello");
 }
}
