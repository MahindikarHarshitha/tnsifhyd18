package com.day3;

public class MultilevelProgrammer2 extends MultilevelPerson1{
	
	String getCodinglanguage() {
		return "Java";
	}

}
