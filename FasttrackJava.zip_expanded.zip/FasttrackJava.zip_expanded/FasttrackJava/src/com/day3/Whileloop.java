package com.day3;

import java.util.Scanner;

public class Whileloop {

	public static void main(String[] args) {
		int num=1;
		while(num<=10)
		{
			System.out.println("numbers" +num);
			num++;
			
		}
		
	}
}
