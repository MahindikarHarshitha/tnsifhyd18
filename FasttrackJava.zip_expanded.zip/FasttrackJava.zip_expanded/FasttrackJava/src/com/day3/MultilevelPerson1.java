package com.day3;

public class MultilevelPerson1 {
	
	String getName() {
		return "progrramerBay";
	}

}
