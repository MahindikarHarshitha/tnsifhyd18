package com.day3;

public class HierarchialInheritenceB extends HierarchialInheritenceA {
	
	public void print() {
		System.out.println("I am a method from class B");
	}

}
