package com.day3;

public interface MultipleBackend {
	
	//abstract method
	public void connectServer() ;

}
