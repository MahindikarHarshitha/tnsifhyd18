package com.day3;

public class Veg extends Person{
	
	@Override
	public void eat() {
		System.out.println("Eats veg");
	}

}
