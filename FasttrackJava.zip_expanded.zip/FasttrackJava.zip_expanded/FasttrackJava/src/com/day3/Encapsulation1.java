package com.day3;

public class Encapsulation1 {
	
	public String name="john";
	public int age=25;
	public String gender="Male";

}


