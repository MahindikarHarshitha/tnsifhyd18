package com.day3;

import java.util.Scanner;

public class Forloop {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		for(num=1;num<10;num++)
		{
			System.out.println("numbers" +num);
		}
		
		
	}
}
