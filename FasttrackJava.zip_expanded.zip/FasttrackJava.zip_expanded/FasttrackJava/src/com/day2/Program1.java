package com.day2;

import java.util.Scanner;

public class Program1 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter your name");
		String name=scanner.nextLine();
		System.out.println("my name is:" +name);
	}

}
