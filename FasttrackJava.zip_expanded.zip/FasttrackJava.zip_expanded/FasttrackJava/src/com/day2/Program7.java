package com.day2;

public class Program7 {
public static void main(String[] args) {
	int y=1;
	int z=12-y;
	System.out.println(z);
}
}
