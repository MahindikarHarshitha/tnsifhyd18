package com.day2;

public class Program9 {
	public static void main(String[] args) {
		int c=2;
		int y=12/c;
		System.out.println(y);
	}

}
