


package com.day2;

public class Car {
	
	public Car() {
		
		//Code block constructor general
	}

}
