package com.day2;

import java.util.Scanner;

public class Program2 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("enter a number:");
		int n=input.nextInt();
		System.out.println("using nextInt():" +n);
	}

}
