package com.day2;

public class Program11 {
	public static void main(String[] args) {
		int x=10;
		System.out.println(x++);
		System.out.println(++x);
	}

}
