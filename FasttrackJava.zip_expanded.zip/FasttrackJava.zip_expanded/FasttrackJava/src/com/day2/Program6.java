package com.day2;

public class Program6 {
	public static void main(String[] args) {
		int x=1+2;
		String s="hello"+"world";
		System.out.println(x);
		System.out.println(s);
	}

}
