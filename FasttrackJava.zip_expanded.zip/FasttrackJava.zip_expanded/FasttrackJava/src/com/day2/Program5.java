package com.day2;

import java.util.Scanner;

public class Program5 {
public static void main(String[] args) {
	Scanner s1=new Scanner(System.in);
	System.out.println("enter a float value");
	float f1=s1.nextFloat();
	System.out.println("using nextfloat():" +f1);
}
}
