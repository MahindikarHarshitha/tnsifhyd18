package com.day2;

public class Program8 {
public static void main(String[] args) {
	int p=2;
	int q=13*p;
	System.out.println(q);
}
}
