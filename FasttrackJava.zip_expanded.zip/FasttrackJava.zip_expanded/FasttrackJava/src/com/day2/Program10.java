package com.day2;

public class Program10 {
public static void main(String[] args) {
	int x=12;
	int y=24%x;
	System.out.println(y);
}
}
