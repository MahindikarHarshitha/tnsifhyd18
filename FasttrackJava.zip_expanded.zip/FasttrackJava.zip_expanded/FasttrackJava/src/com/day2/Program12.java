package com.day2;

public class Program12 {
	public static void main(String[] args) {
		int y=10;
		System.out.println(y--);
		System.out.println(--y);
	}

}
