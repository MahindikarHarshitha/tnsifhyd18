package com.day2;

public class Program14 {
public static void main(String[] args) {
	int x=10;
	x+=5;
	System.out.println(x);
	int y=10;
	y-=3;
	System.out.println(y);
	int z=10;
	z*=5;
	System.out.println(z);
	int p=10;
	p/=2;
	System.out.println(p);
	int q=20;
	q%=2;
	System.out.println(q);
}
}
