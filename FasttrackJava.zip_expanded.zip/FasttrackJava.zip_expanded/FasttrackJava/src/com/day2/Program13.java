package com.day2;

public class Program13 {
public static void main(String[] args) {
	boolean x;
	x=(10<5)?true:false;
	System.out.println(x);
	int age=12;
	String a="allowed to vote";
	String b="not allowed to vote";
	String c=(age>18)?a:b;
	System.out.println(c);
}
}
