package com.day2;

import java.util.Scanner;

public class Program3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the double value");
		double d1=sc.nextDouble();
		System.out.println("using nextDouble():" +d1);
}
}
