package com.day1;

public class ProtectedMain extends ProtectedA  {
	public static void main(String[] args) {
		ProtectedA obj = new ProtectedA();
		obj.display();
		}

	
	}



