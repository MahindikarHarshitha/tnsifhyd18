package com.day1;

public class Program2 {

	public static void main(String[] args) {
         int number=10;
         if(number%2==0)
         {
        	 System.out.println("given number is even" +number);
         }
         else 
         {
        	 System.out.println("given number is a odd number" +number);
         }
	}

}
//even or odd