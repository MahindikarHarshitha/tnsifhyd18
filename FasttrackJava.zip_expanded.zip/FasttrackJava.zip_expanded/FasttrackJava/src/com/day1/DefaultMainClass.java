package com.day1;

public class DefaultMainClass {
	public static void main(String[] args) {
		DefaultA obj=new DefaultA();
		obj.display();
	}

}
