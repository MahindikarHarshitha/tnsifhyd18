package com.day1;

public class Program3 {
     public static void main(String[] args) {
    	 int i , fact=1;
    	 int num=6;
    	 for(i=1;i<=num;i++)
    	 {
    		 fact=fact*i;
    	 }
    	 System.out.println("factorial of" + num   +fact );
		 
	}
}
//factorial