package com.day1;

import java.util.Scanner;

public class Program11 {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter first number");
		double num1=scanner.nextDouble();
		System.out.println("enter second number");
		double num2=scanner.nextDouble();
		double average=(num1+num2)/2;
		System.out.println("the average of" +num1+ "and" +num2+ "is" +average);
		scanner.close();
	}

}
//average of 2 numbers