package com.day1;

public class Program5 {
 public static void main(String[] args) {
	int a=21,b=11,c=1;
	if(a>=b&&a>=c)
	{
		System.out.println(a+ "largest number");
	}
	else if(b>=a&&b>=c)
	{
		System.out.println(b+ "largest number");
	}
	else
	{
		System.err.println(c+ "largest number");
}


	
}
}
//largest number