package com.day1;

import java.util.Scanner;

public class Program15 {
 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("emter number");
	int n = scanner.nextInt();
	int sum=0;
	for(int i=1;i<=n;i++)
	{
		sum+=i;
	}
     System.out.println("sum of naturanal numbers up to" +n+ "is:" +sum);
}
}
