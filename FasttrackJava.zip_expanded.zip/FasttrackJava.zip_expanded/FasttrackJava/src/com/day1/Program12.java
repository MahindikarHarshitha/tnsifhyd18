package com.day1;

import java.util.Scanner;

public class Program12 {
 public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);

	System.out.println("enter first string");
	String str1=scanner.nextLine();
	System.out.println("enter second string");
	String str2=scanner.nextLine();
	String concatenatedString=str1+str2;
	System.out.println("the concatenation of two string is:" +concatenatedString);
	scanner.close();
	
}
}
