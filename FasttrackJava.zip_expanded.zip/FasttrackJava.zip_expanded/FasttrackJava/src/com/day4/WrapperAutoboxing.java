package com.day4;

public class WrapperAutoboxing {
	public static void main(String[] args) {
		int a=55;
		double b=3.56756;
		Integer aObj=Integer.valueOf(a);
		Double bObj=Double.valueOf(b);
		if(aObj instanceof Integer)
		{
			System.out.println("an object of integer is created");
		}
		if(bObj instanceof Double)
		{
			System.out.println("an object of double is created");
		}
	}

}
