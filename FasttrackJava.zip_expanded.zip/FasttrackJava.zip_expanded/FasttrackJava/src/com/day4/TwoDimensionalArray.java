package com.day4;

public class TwoDimensionalArray {
public static void main(String[] args) {
	int a[][]= {{2,3,7},{3,6,1},{7,4,2}};
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
			System.out.println(a[i][j] + "");
	}


}
}
