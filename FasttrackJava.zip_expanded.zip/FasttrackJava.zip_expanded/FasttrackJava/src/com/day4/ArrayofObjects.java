package com.day4;

public class ArrayofObjects {
	public int rollno;
	public String name;
	ArrayofObjects(int rollno,String name)
	{
		this.rollno=rollno;
		this.name=name;
	}

}
