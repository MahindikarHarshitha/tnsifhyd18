package com.day4;

public class StringBufferClass {

public static void main(String[] args) {
	StringBuffer sb=new StringBuffer("hello");
	 sb.append("java");
	 sb.reverse();
	 sb.replace(1, 2, "hi");
	 sb.delete(1,3);
	 System.out.println(sb);
	 
	
}
}
