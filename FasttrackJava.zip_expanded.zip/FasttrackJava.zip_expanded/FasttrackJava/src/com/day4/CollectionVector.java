package com.day4;

import java.util.Vector;

public class CollectionVector {
public static void main(String[] args) {
	Vector<Integer> v=new Vector<Integer>();
	for(int i=0;i<=5;i++)
		v.add(i);
	System.out.println(v);
	v.remove(4);
	System.out.println(v);
	for(int i=0;i<v.size();i++)
		System.out.println(v.get(i) + " ");
}
}
