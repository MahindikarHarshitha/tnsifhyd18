package com.day4;

public class StringClass {
	public static void main(String[] args) {
		String s="harshitha";
		s.concat("mehendikar");
		System.out.println(s);
	}

}
//IMMUTABLE STRINGS STRING CLASS