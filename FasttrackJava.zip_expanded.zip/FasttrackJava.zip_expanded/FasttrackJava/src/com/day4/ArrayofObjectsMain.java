package com.day4;

public class ArrayofObjectsMain {
	public static void main(String[] args) {
		ArrayofObjects[] arr;
		arr=new ArrayofObjects[5];
		arr[0]=new ArrayofObjects(1,"puchki");
		arr[1]=new ArrayofObjects(2,"meghansh");
		arr[2]=new ArrayofObjects(3,"nidhi");
		arr[3]=new ArrayofObjects(4,"vihaan");
		arr[4]=new ArrayofObjects(5,"hasrsh");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("elemenys at" +i+ ":" + arr[i].rollno + " " + arr[i].name);
		}
		
	}

}
