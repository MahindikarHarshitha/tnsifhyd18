package com.day4;

public class WrapperUnboxing {
public static void main(String[] args) {
	Integer aObj=Integer.valueOf(16);
	Double bObj=Double.valueOf(2004.10);
	int a=aObj.intValue();
	double b=bObj.doubleValue();
	System.out.println(a);
	System.out.println(b);
}
}
