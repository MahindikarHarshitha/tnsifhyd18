package com.day4;

public class StringBuilderClass {
public static void main(String[] args) {
	StringBuilder sb=new StringBuilder("harshitha");
	sb.insert(9,"mehendikar");
	sb.append("Dayanand");
	sb.reverse();
	sb.replace(0, 1, "dharani");
	System.out.println(sb);
}
}
