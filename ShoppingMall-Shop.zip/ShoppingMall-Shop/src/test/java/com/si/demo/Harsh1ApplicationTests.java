package com.si.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Harsh1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
