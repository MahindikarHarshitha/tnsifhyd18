package com.si.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.si.demo.entity.Shop;
import com.si.demo.repository.ShopRepository;

@Service

public class ShopServiceImpl implements ShopService {
	
	@Autowired
	private ShopRepository sr;
	
	 @Override
	    public Shop saveShop(Shop shop) {
	        return sr.save(shop);
	    }

	@Override
	public List<Shop> fetchShopList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shop fetchShopById(Long shopId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteShopById(Long shopId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Shop updateShop(Long shopId, Shop shop) {
		// TODO Auto-generated method stub
		return null;
	}

}
