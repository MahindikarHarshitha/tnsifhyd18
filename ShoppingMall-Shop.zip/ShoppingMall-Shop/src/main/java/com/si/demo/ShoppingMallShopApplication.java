package com.si.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMallShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMallShopApplication.class, args);
	}

}
